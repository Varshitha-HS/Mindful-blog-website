import React, { useEffect } from 'react';
import { useLocation } from 'wouter';
import { Post } from '@/lib/data';
import CommentForm from './CommentForm';
import CommentList from './CommentList';
import { useQuery } from '@tanstack/react-query';
import { Comment } from '@shared/schema';

interface BlogContentProps {
  post: Post;
}

const BlogContent: React.FC<BlogContentProps> = ({ post }) => {
  const [, setLocation] = useLocation();

  // Fetch comments for this specific post
  const { data: comments = [] as Comment[] } = useQuery<Comment[]>({
    queryKey: [`/api/posts/${post.id}/comments`],
  });

  useEffect(() => {
    // Scroll to top when post is loaded
    window.scrollTo(0, 0);
  }, [post.id]);

  const handleSocialShare = (platform: string) => {
    // This would be implemented with actual social media sharing APIs
    console.log(`Sharing post on ${platform}`);
    // For a real implementation, you would use the navigator.share API if available
    // or open a popup with the appropriate social media sharing link
  };

  return (
    <article className="blog-post mb-16 bg-white rounded-xl overflow-hidden shadow-lg max-w-4xl mx-auto">
      <img 
        src={post.imageSrc} 
        alt={post.imageAlt} 
        className="w-full h-96 object-cover" 
      />
      
      <div className="p-8">
        <div className="flex items-center justify-between mb-6">
          <div className="text-gray-500">{post.date}</div>
          <div className="flex space-x-3">
            {post.categories && post.categories.map((category, index) => (
              <span 
                key={index}
                className={`inline-flex items-center px-3 py-1 rounded-full text-sm font-medium ${category.bgColor} ${category.textColor}`}
              >
                {category.name}
              </span>
            ))}
          </div>
        </div>
        
        <h2 className="text-3xl font-bold mb-6">{post.title}</h2>
        
        <div className="prose lg:prose-lg max-w-none" dangerouslySetInnerHTML={{ __html: post.content }} />
        
        {/* Social Sharing */}
        <div className="border-t border-b border-gray-200 py-6 my-8">
          <div className="flex items-center justify-between">
            <div>
              <span className="text-gray-600 mr-2">Share this article:</span>
              <button 
                className="text-blue-600 hover:text-blue-800 mx-1"
                onClick={() => handleSocialShare('facebook')}
                aria-label="Share on Facebook"
              >
                <i className="fab fa-facebook-f"></i>
              </button>
              <button 
                className="text-blue-400 hover:text-blue-600 mx-1"
                onClick={() => handleSocialShare('twitter')}
                aria-label="Share on Twitter"
              >
                <i className="fab fa-twitter"></i>
              </button>
              <button 
                className="text-blue-700 hover:text-blue-900 mx-1"
                onClick={() => handleSocialShare('linkedin')}
                aria-label="Share on LinkedIn"
              >
                <i className="fab fa-linkedin-in"></i>
              </button>
              <button 
                className="text-green-600 hover:text-green-800 mx-1"
                onClick={() => handleSocialShare('email')}
                aria-label="Share via Email"
              >
                <i className="far fa-envelope"></i>
              </button>
            </div>
            <div>
              <button 
                className="inline-flex items-center text-gray-600 hover:text-primary"
                aria-label="Save for later"
              >
                <i className="far fa-bookmark mr-2"></i> Save for later
              </button>
            </div>
          </div>
        </div>
        
        {/* Author Info */}
        {post.author && (
          <div className="flex items-center mt-8 mb-12">
            <img 
              src={post.author.avatar} 
              alt={post.author.name} 
              className="w-12 h-12 rounded-full mr-4" 
            />
            <div>
              <div className="font-medium">{post.author.name}</div>
              <div className="text-sm text-gray-500">{post.author.role}</div>
            </div>
          </div>
        )}
        
        {/* Comments Section */}
        <div className="mt-12">
          <h3 className="text-2xl font-bold mb-6">Comments ({comments.length})</h3>
          
          {/* Comment Form */}
          <CommentForm postId={post.id} />
          
          {/* Comments List */}
          <CommentList comments={comments} />
        </div>
      </div>
    </article>
  );
};

export default BlogContent;
