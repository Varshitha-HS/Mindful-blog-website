import React from 'react';
import { Link } from 'wouter';
import { Post } from '@/lib/data';

interface BlogPostCardProps {
  post: Post;
}

const BlogPostCard: React.FC<BlogPostCardProps> = ({ post }) => {
  return (
    <article className="bg-white rounded-lg overflow-hidden shadow-md transition-transform hover:shadow-lg hover:-translate-y-1">
      <Link href={`/post/${post.id}`}>
        <img 
          src={post.imageSrc} 
          alt={post.imageAlt} 
          className="w-full h-48 object-cover" 
        />
        <div className="p-6">
          <div className="text-sm text-gray-500 mb-2">{post.date}</div>
          <h3 className="text-xl font-semibold mb-2">{post.title}</h3>
          <p className="text-gray-600 mb-4">{post.excerpt}</p>
          <div className="flex items-center text-sm text-primary">
            Read more <i className="fas fa-arrow-right ml-2"></i>
          </div>
        </div>
      </Link>
    </article>
  );
};

export default BlogPostCard;
