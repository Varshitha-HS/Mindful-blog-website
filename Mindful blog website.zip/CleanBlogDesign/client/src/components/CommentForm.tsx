import React from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { apiRequest } from '@/lib/queryClient';
import { useToast } from '@/hooks/use-toast';
import { queryClient } from '@/lib/queryClient';

// Validation schema for the comment form
const formSchema = z.object({
  name: z.string().min(2, { message: 'Name must be at least 2 characters' }),
  content: z.string().min(5, { message: 'Comment must be at least 5 characters' })
});

type FormValues = z.infer<typeof formSchema>;

interface CommentFormProps {
  postId: number;
}

const CommentForm: React.FC<CommentFormProps> = ({ postId }) => {
  const { toast } = useToast();
  
  const form = useForm<FormValues>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      name: '',
      content: ''
    }
  });
  
  const onSubmit = async (data: FormValues) => {
    try {
      await apiRequest('POST', `/api/posts/${postId}/comments`, {
        ...data,
        postId
      });
      
      // Clear the form after successful submission
      form.reset();
      
      // Invalidate the query to refresh the comments list
      queryClient.invalidateQueries({ queryKey: [`/api/posts/${postId}/comments`] });
      
      toast({
        title: 'Comment Posted',
        description: 'Your comment has been successfully posted.',
      });
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : 'Something went wrong';
      
      toast({
        title: 'Error',
        description: errorMessage,
        variant: 'destructive'
      });
    }
  };

  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(onSubmit)} className="mb-8">
        <FormField
          control={form.control}
          name="name"
          render={({ field }) => (
            <FormItem className="mb-4">
              <FormLabel className="block text-sm font-medium text-gray-700 mb-1">Name</FormLabel>
              <FormControl>
                <Input
                  {...field}
                  className="w-full px-4 py-2 border border-gray-300 rounded-md focus:ring-primary focus:border-primary"
                  placeholder="Your name"
                />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />
        
        <FormField
          control={form.control}
          name="content"
          render={({ field }) => (
            <FormItem className="mb-4">
              <FormLabel className="block text-sm font-medium text-gray-700 mb-1">Comment</FormLabel>
              <FormControl>
                <textarea
                  {...field}
                  rows={4}
                  className="w-full px-4 py-2 border border-gray-300 rounded-md focus:ring-primary focus:border-primary"
                  placeholder="Your comment"
                />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />
        
        <Button 
          type="submit" 
          disabled={form.formState.isSubmitting}
          className="bg-primary hover:bg-secondary text-white px-6 py-2 rounded-md transition-colors"
        >
          {form.formState.isSubmitting ? 'Posting...' : 'Post Comment'}
        </Button>
      </form>
    </Form>
  );
};

export default CommentForm;
