import React from 'react';
import { Comment } from '@shared/schema';

interface CommentListProps {
  comments: Comment[];
}

const CommentList: React.FC<CommentListProps> = ({ comments }) => {
  // Format the date
  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    });
  };

  return (
    <div className="space-y-6">
      {comments.length === 0 ? (
        <p className="text-gray-500 italic">No comments yet. Be the first to share your thoughts!</p>
      ) : (
        comments.map((comment) => (
          <div key={comment.id} className="comment bg-gray-50 p-4 rounded-lg">
            <div className="flex justify-between">
              <h4 className="font-semibold">{comment.name}</h4>
              <span className="text-sm text-gray-500">{formatDate(comment.createdAt)}</span>
            </div>
            <p className="mt-2">{comment.content}</p>
          </div>
        ))
      )}
    </div>
  );
};

export default CommentList;
