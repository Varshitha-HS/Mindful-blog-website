import React from 'react';
import { Link } from 'wouter';

const Footer: React.FC = () => {
  return (
    <footer className="bg-gray-800 text-gray-300">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          <div className="md:col-span-1">
            <h3 className="text-xl font-bold text-white mb-4">Mindful Living</h3>
            <p className="mb-4">Exploring the art of balanced, intentional living in a fast-paced world.</p>
            <div className="flex space-x-4">
              <a href="#" className="text-gray-300 hover:text-white" aria-label="Facebook">
                <i className="fab fa-facebook-f"></i>
              </a>
              <a href="#" className="text-gray-300 hover:text-white" aria-label="Twitter">
                <i className="fab fa-twitter"></i>
              </a>
              <a href="#" className="text-gray-300 hover:text-white" aria-label="Instagram">
                <i className="fab fa-instagram"></i>
              </a>
              <a href="#" className="text-gray-300 hover:text-white" aria-label="Pinterest">
                <i className="fab fa-pinterest"></i>
              </a>
            </div>
          </div>
          
          <div>
            <h4 className="text-lg font-semibold text-white mb-4">Categories</h4>
            <ul className="space-y-2">
              <li><Link href="/category/wellness" className="hover:text-white">Wellness</Link></li>
              <li><Link href="/category/nutrition" className="hover:text-white">Nutrition</Link></li>
              <li><Link href="/category/mental-health" className="hover:text-white">Mental Health</Link></li>
              <li><Link href="/category/sustainability" className="hover:text-white">Sustainability</Link></li>
              <li><Link href="/category/relationships" className="hover:text-white">Relationships</Link></li>
            </ul>
          </div>
          
          <div>
            <h4 className="text-lg font-semibold text-white mb-4">About</h4>
            <ul className="space-y-2">
              <li><Link href="/about" className="hover:text-white">Our Story</Link></li>
              <li><Link href="/team" className="hover:text-white">Meet the Team</Link></li>
              <li><Link href="/contact" className="hover:text-white">Contact Us</Link></li>
              <li><Link href="/write-for-us" className="hover:text-white">Write for Us</Link></li>
              <li><Link href="/privacy" className="hover:text-white">Privacy Policy</Link></li>
            </ul>
          </div>
          
          <div>
            <h4 className="text-lg font-semibold text-white mb-4">Resources</h4>
            <ul className="space-y-2">
              <li><Link href="/resources/meditation" className="hover:text-white">Free Meditation Guide</Link></li>
              <li><Link href="/resources/toolkit" className="hover:text-white">Wellness Toolkit</Link></li>
              <li><Link href="/resources/books" className="hover:text-white">Recommended Books</Link></li>
              <li><Link href="/community" className="hover:text-white">Community Forum</Link></li>
              <li><Link href="/events" className="hover:text-white">Events Calendar</Link></li>
            </ul>
          </div>
        </div>
        
        <div className="border-t border-gray-700 mt-12 pt-8 text-sm text-center">
          <p>&copy; {new Date().getFullYear()} Mindful Living Blog. All rights reserved.</p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
