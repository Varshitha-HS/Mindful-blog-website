import React from 'react';
import SearchBar from './SearchBar';

const Hero: React.FC = () => {
  return (
    <section className="bg-gradient-to-r from-blue-500 to-blue-600 text-white py-16">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="max-w-3xl mx-auto text-center">
          <h1 className="text-4xl font-bold mb-4">Welcome to Mindful Living</h1>
          <p className="text-xl mb-8">Insights and stories about living a balanced, purposeful life</p>
          
          {/* Search Bar */}
          <div className="max-w-lg mx-auto">
            <SearchBar />
          </div>
        </div>
      </div>
    </section>
  );
};

export default Hero;
