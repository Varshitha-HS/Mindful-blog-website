import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';

const Newsletter: React.FC = () => {
  const [email, setEmail] = useState('');
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [error, setError] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    // Basic email validation
    if (!email || !email.includes('@') || !email.includes('.')) {
      setError('Please enter a valid email address');
      return;
    }
    
    // Reset error if any
    setError('');
    
    // In a real app, you would send this to your backend
    console.log('Subscribing email:', email);
    
    // Show success message
    setIsSubmitted(true);
    
    // Reset form
    setEmail('');
    
    // Reset success message after 5 seconds
    setTimeout(() => {
      setIsSubmitted(false);
    }, 5000);
  };

  return (
    <section className="bg-gray-100 py-16">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="max-w-xl mx-auto text-center">
          <h2 className="text-3xl font-bold mb-4">Join Our Newsletter</h2>
          <p className="text-gray-600 mb-8">
            Get the latest articles, resources and tips about mindful living delivered directly to your inbox.
          </p>
          
          {isSubmitted ? (
            <div className="text-green-600 mb-4 font-medium">
              Thank you for subscribing! Check your inbox to confirm your subscription.
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="flex flex-col sm:flex-row gap-4">
              <Input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="Your email address"
                className="flex-grow px-4 py-3 rounded-md border border-gray-300 focus:ring-primary focus:border-primary"
                aria-label="Email address"
              />
              <Button 
                type="submit" 
                className="px-6 py-3 bg-primary hover:bg-secondary text-white font-medium rounded-md transition-colors"
              >
                Subscribe
              </Button>
            </form>
          )}
          
          {error && <p className="text-sm text-red-600 mt-2">{error}</p>}
          
          <p className="text-sm text-gray-500 mt-4">We respect your privacy. Unsubscribe at any time.</p>
        </div>
      </div>
    </section>
  );
};

export default Newsletter;
