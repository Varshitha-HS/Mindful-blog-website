// This file contains the blog post data in a structured format
// In a real application, this would come from an API/database

export interface Category {
  name: string;
  bgColor: string;
  textColor: string;
}

export interface Author {
  name: string;
  role: string;
  avatar: string;
}

export interface Post {
  id: number;
  title: string;
  slug: string;
  date: string;
  excerpt: string;
  content: string;
  imageSrc: string;
  imageAlt: string;
  categories: Category[];
  author: Author;
}

// Blog post data
export const blogPosts: Post[] = [
  {
    id: 1,
    title: "The Power of Morning Routines",
    slug: "the-power-of-morning-routines",
    date: "May 15, 2025",
    excerpt: "Discover how establishing a consistent morning practice can transform your day and enhance productivity.",
    content: `
      <p>In today's fast-paced world, the way we start our mornings can significantly influence how the rest of our day unfolds. A thoughtfully designed morning routine has the power to set a positive tone, enhance productivity, and contribute to overall well-being.</p>
      
      <h3 class="text-xl font-semibold mt-6 mb-4">Why Morning Routines Matter</h3>
      
      <p>The first hours after waking represent a unique opportunity to intentionally direct your day rather than immediately reacting to external demands. Research shows that willpower is typically strongest in the morning, making it the ideal time to engage in activities that align with your values and goals.</p>
      
      <p>By establishing consistent morning practices, you're essentially creating a foundation of stability amidst life's unpredictability. This structured approach helps reduce decision fatigue and conserves mental energy for more important matters throughout the day.</p>
      
      <h3 class="text-xl font-semibold mt-6 mb-4">Building Your Ideal Morning Routine</h3>
      
      <p>The most effective morning routines are personalized to individual preferences, chronotypes, and objectives. However, certain elements tend to appear in many successful routines:</p>
      
      <ul class="list-disc pl-5 my-4">
        <li><strong>Hydration:</strong> Replenishing water lost during sleep</li>
        <li><strong>Movement:</strong> Activating the body through stretching, yoga, or exercise</li>
        <li><strong>Mindfulness:</strong> Meditation, journaling, or breathing exercises</li>
        <li><strong>Planning:</strong> Reviewing priorities and intentions for the day</li>
        <li><strong>Learning:</strong> Reading or engaging with inspiring content</li>
      </ul>
      
      <p>The key is not to incorporate every possible element but to select practices that resonate with you and can be sustained consistently over time.</p>
      
      <h3 class="text-xl font-semibold mt-6 mb-4">Starting Small for Lasting Change</h3>
      
      <p>Rather than attempting a complete morning overhaul, consider beginning with one or two practices that feel achievable. Gradually building upon small successes creates momentum and increases the likelihood of maintaining your routine long-term.</p>
      
      <p>Remember that the goal isn't perfection but progress. Some mornings won't go as planned, and that's perfectly normal. The power lies in returning to your routine the next day, creating a positive cycle that compounds over time.</p>
      
      <p>By investing in how you begin each day, you're making a meaningful commitment to your well-being and setting yourself up for greater fulfillment, focus, and intentionality in all areas of life.</p>
    `,
    imageSrc: "https://images.unsplash.com/photo-1507525428034-b723cf961d3e?ixlib=rb-1.2.1&auto=format&fit=crop&w=1200&q=80",
    imageAlt: "Morning beach meditation",
    categories: [
      { name: "Wellness", bgColor: "bg-blue-100", textColor: "text-blue-800" },
      { name: "Habits", bgColor: "bg-green-100", textColor: "text-green-800" }
    ],
    author: {
      name: "Emma Johnson",
      role: "Wellness Coach & Writer",
      avatar: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?ixlib=rb-1.2.1&auto=format&fit=crop&w=120&q=80"
    }
  },
  {
    id: 2,
    title: "Mindful Eating Practices",
    slug: "mindful-eating-practices",
    date: "June 3, 2025",
    excerpt: "Learn how paying attention to your food can improve digestion, satisfaction, and overall relationship with eating.",
    content: `
      <p>In our busy modern lives, eating has often become a mindless activity that we rush through while multitasking. Mindful eating offers an alternative approach—one that transforms our relationship with food and nourishes both body and mind.</p>
      
      <h3 class="text-xl font-semibold mt-6 mb-4">What Is Mindful Eating?</h3>
      
      <p>Mindful eating is the practice of paying full attention to the experience of eating and drinking, both inside and outside the body. It involves observing the colors, smells, textures, flavors, temperatures, and even the sounds of our food. It's about noticing the body's hunger signals and respecting its fullness cues.</p>
      
      <p>This approach isn't about perfect eating or following strict dietary rules. Rather, it's about developing awareness of how food affects our bodies and feelings, making conscious choices, and savoring each bite.</p>
      
      <h3 class="text-xl font-semibold mt-6 mb-4">Benefits of Mindful Eating</h3>
      
      <p>Research suggests that mindful eating can provide numerous benefits:</p>
      
      <ul class="list-disc pl-5 my-4">
        <li>Improved digestion through thorough chewing and slower eating pace</li>
        <li>Better portion control and recognition of satiety signals</li>
        <li>Enhanced enjoyment and satisfaction from meals</li>
        <li>Reduction in stress-related and emotional eating</li>
        <li>More balanced relationship with food and eating</li>
        <li>Natural weight management without restrictive dieting</li>
      </ul>
      
      <h3 class="text-xl font-semibold mt-6 mb-4">Simple Practices to Begin With</h3>
      
      <p>Incorporating mindful eating doesn't require a complete overhaul of your habits. Here are some accessible starting points:</p>
      
      <ol class="list-decimal pl-5 my-4">
        <li><strong>Express gratitude:</strong> Before eating, take a moment to appreciate where your food came from and all who helped bring it to your table.</li>
        <li><strong>Eliminate distractions:</strong> Turn off screens and put away devices during mealtimes.</li>
        <li><strong>Engage your senses:</strong> Notice the appearance, aroma, texture, and taste of each food item.</li>
        <li><strong>Eat slowly:</strong> Put down your utensils between bites and chew thoroughly.</li>
        <li><strong>Check in with your hunger:</strong> Pause midway through your meal to assess your level of fullness.</li>
      </ol>
      
      <p>Even implementing just one of these practices can begin to shift your relationship with food in a positive direction.</p>
      
      <h3 class="text-xl font-semibold mt-6 mb-4">Mindful Eating in the Real World</h3>
      
      <p>While the concept is simple, applying mindful eating in everyday life can be challenging. Start by choosing one meal per day or even one meal per week to practice fully mindful eating. Gradually extend this practice to more meals as it becomes more natural.</p>
      
      <p>Remember that mindful eating is not about perfection but about presence. Each meal offers a new opportunity to practice awareness and connection with your food and body.</p>
      
      <p>By bringing consciousness to this fundamental daily activity, you can transform routine nourishment into a meaningful practice that supports your overall well-being and deepens your appreciation for the gift of food.</p>
    `,
    imageSrc: "https://images.unsplash.com/photo-1512621776951-a57141f2eefd?ixlib=rb-1.2.1&auto=format&fit=crop&w=1200&q=80",
    imageAlt: "Healthy meal preparation",
    categories: [
      { name: "Nutrition", bgColor: "bg-blue-100", textColor: "text-blue-800" },
      { name: "Mindfulness", bgColor: "bg-yellow-100", textColor: "text-yellow-800" }
    ],
    author: {
      name: "Daniel Wright",
      role: "Nutritionist & Mindfulness Coach",
      avatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?ixlib=rb-1.2.1&auto=format&fit=crop&w=120&q=80"
    }
  },
  {
    id: 3,
    title: "Nature Therapy: Healing in the Wild",
    slug: "nature-therapy-healing-in-the-wild",
    date: "July 21, 2025",
    excerpt: "Explore how spending time in natural settings can reduce stress, anxiety, and boost your mental wellbeing.",
    content: `
      <p>In an increasingly digital and urban world, many of us have become disconnected from the natural environment that humans evolved alongside for millennia. This separation may be contributing to rising rates of stress, anxiety, and other mental health challenges. Nature therapy, also known as ecotherapy or green therapy, offers a powerful antidote to this modern condition.</p>
      
      <h3 class="text-xl font-semibold mt-6 mb-4">The Science Behind Nature's Healing Power</h3>
      
      <p>A growing body of research confirms what many have intuitively felt: spending time in natural settings has measurable physical and psychological benefits. Studies show that nature exposure can:</p>
      
      <ul class="list-disc pl-5 my-4">
        <li>Reduce cortisol (stress hormone) levels</li>
        <li>Lower blood pressure and heart rate</li>
        <li>Decrease symptoms of depression and anxiety</li>
        <li>Improve concentration and cognitive function</li>
        <li>Boost immune system functioning</li>
        <li>Enhance creativity and problem-solving abilities</li>
      </ul>
      
      <p>One fascinating area of research focuses on phytoncides—organic compounds released by trees and plants that we inhale when in forested areas. These compounds appear to boost our natural killer (NK) cells, a type of white blood cell crucial for fighting infections and cancer.</p>
      
      <h3 class="text-xl font-semibold mt-6 mb-4">Forms of Nature Therapy</h3>
      
      <p>Nature therapy encompasses a spectrum of practices, from structured therapeutic approaches to simple activities that reconnect us with the natural world:</p>
      
      <ol class="list-decimal pl-5 my-4">
        <li><strong>Forest Bathing (Shinrin-Yoku):</strong> Originating in Japan, this practice involves mindfully immersing yourself in a forest environment, engaging all senses without any particular goal other than presence.</li>
        <li><strong>Wilderness Therapy:</strong> Usually conducted in groups, this approach uses challenging outdoor experiences to foster personal growth, resilience, and interpersonal skills.</li>
        <li><strong>Horticultural Therapy:</strong> Involves gardening and plant care as therapeutic activities that promote well-being through nurturing living things.</li>
        <li><strong>Animal-Assisted Therapy:</strong> Incorporates interactions with animals in natural settings to reduce stress and promote healing.</li>
        <li><strong>Adventure Therapy:</strong> Uses outdoor adventure activities like hiking, rock climbing, or kayaking to build confidence and process emotional challenges.</li>
      </ol>
      
      <h3 class="text-xl font-semibold mt-6 mb-4">Incorporating Nature Into Everyday Life</h3>
      
      <p>You don't need access to remote wilderness to benefit from nature therapy. Even small doses of nature connection can be beneficial:</p>
      
      <ul class="list-disc pl-5 my-4">
        <li>Spend time in local parks, gardens, or green spaces</li>
        <li>Bring plants into your home and workplace</li>
        <li>Walk barefoot on grass or soil (sometimes called "grounding" or "earthing")</li>
        <li>Observe seasonal changes in your neighborhood</li>
        <li>Eat lunch outdoors instead of at your desk</li>
        <li>Watch sunrise or sunset regularly</li>
        <li>Tend to even a small balcony garden or windowsill plants</li>
      </ul>
      
      <p>The key is consistency—regular contact with natural elements, even in small doses, appears more beneficial than occasional immersive experiences.</p>
      
      <h3 class="text-xl font-semibold mt-6 mb-4">Nature Therapy for Modern Challenges</h3>
      
      <p>As we face increasing rates of burnout, digital fatigue, and disconnection, nature therapy offers a accessible and effective complement to other wellness practices. By deliberately reconnecting with the natural world, we can access an ancient source of healing that remains as powerful today as it has been throughout human evolution.</p>
      
      <p>Whether you're managing chronic stress, recovering from illness, or simply seeking greater well-being, consider how you might bring more nature into your healing journey. The forest, the ocean, the mountains, or even the neighborhood park might hold exactly the medicine your mind and body need.</p>
    `,
    imageSrc: "https://images.unsplash.com/photo-1506126613408-eca07ce68773?ixlib=rb-1.2.1&auto=format&fit=crop&w=1200&q=80",
    imageAlt: "Forest hiking trail",
    categories: [
      { name: "Nature", bgColor: "bg-green-100", textColor: "text-green-800" },
      { name: "Mental Health", bgColor: "bg-purple-100", textColor: "text-purple-800" }
    ],
    author: {
      name: "Thomas Rivera",
      role: "Environmental Psychologist",
      avatar: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?ixlib=rb-1.2.1&auto=format&fit=crop&w=120&q=80"
    }
  }
];

// Function to get post by ID
export const getPostById = (id: number): Post | undefined => {
  return blogPosts.find(post => post.id === id);
};

// Function to get post by slug
export const getPostBySlug = (slug: string): Post | undefined => {
  return blogPosts.find(post => post.slug === slug);
};
