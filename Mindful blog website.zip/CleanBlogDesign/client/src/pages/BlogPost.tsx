import React, { useEffect } from 'react';
import { useRoute, useLocation } from 'wouter';
import { useQuery } from '@tanstack/react-query';
import Header from '@/components/Header';
import Footer from '@/components/Footer';
import Newsletter from '@/components/Newsletter';
import BlogContent from '@/components/BlogContent';
import { getPostById, Post } from '@/lib/data';

const BlogPost: React.FC = () => {
  const [, setLocation] = useLocation();
  const [match, params] = useRoute('/post/:id');
  
  // Get the post ID from URL parameters
  const postId = match && params ? parseInt(params.id, 10) : null;
  
  // Fetch the post using React Query
  // In a real app, this would fetch from an API
  const { data: post, isLoading, isError } = useQuery<Post>({
    queryKey: [`/api/posts/${postId}`],
    enabled: !!postId,
    retry: 1, // Limit retries
  });
  
  // If the post ID is invalid or not found, redirect to home
  useEffect(() => {
    if (!isLoading && (!post || isError)) {
      setLocation('/');
    }
  }, [post, isLoading, isError, setLocation]);

  // For demo purposes, we're using the local data as a fallback
  const postData = post || (postId ? getPostById(postId) : null);

  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      
      <main className="container mx-auto px-4 sm:px-6 lg:px-8 py-12 flex-grow">
        {isLoading ? (
          // Loading state
          <div className="max-w-4xl mx-auto bg-white rounded-xl overflow-hidden shadow-lg p-8">
            <div className="animate-pulse">
              <div className="bg-gray-300 h-96 w-full rounded mb-8"></div>
              <div className="h-4 bg-gray-300 rounded w-1/4 mb-4"></div>
              <div className="h-8 bg-gray-300 rounded w-3/4 mb-8"></div>
              <div className="space-y-4">
                <div className="h-4 bg-gray-300 rounded w-full"></div>
                <div className="h-4 bg-gray-300 rounded w-full"></div>
                <div className="h-4 bg-gray-300 rounded w-3/4"></div>
              </div>
            </div>
          </div>
        ) : (postData && postData.id && postData.title) ? (
          <BlogContent post={postData as Post} />
        ) : (
          <div className="text-center py-12">
            <h2 className="text-2xl font-bold text-gray-700">Post not found</h2>
            <p className="mt-2 text-gray-500">The post you're looking for doesn't exist or has been removed.</p>
            <button
              onClick={() => setLocation('/')}
              className="mt-4 inline-flex items-center px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-primary hover:bg-secondary"
            >
              Back to Home
            </button>
          </div>
        )}
      </main>
      
      <Newsletter />
      <Footer />
    </div>
  );
};

export default BlogPost;
