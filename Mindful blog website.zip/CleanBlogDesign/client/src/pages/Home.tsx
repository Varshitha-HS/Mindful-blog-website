import React from 'react';
import { useQuery } from '@tanstack/react-query';
import Header from '@/components/Header';
import Hero from '@/components/Hero';
import BlogPostCard from '@/components/BlogPostCard';
import Newsletter from '@/components/Newsletter';
import Footer from '@/components/Footer';
import { blogPosts } from '@/lib/data';

const Home: React.FC = () => {
  // Fetch posts using React Query
  // In a real app, this would be fetching from an API
  const { data: posts = blogPosts, isLoading } = useQuery({
    queryKey: ['/api/posts'],
  });

  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      <Hero />
      
      <main className="container mx-auto px-4 sm:px-6 lg:px-8 py-12 flex-grow">
        {/* Featured Posts Section */}
        <section className="mb-16">
          <h2 className="text-3xl font-bold mb-8 text-center">Featured Posts</h2>
          
          {isLoading ? (
            // Loading state
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              {[1, 2, 3].map((_, index) => (
                <div key={index} className="bg-white rounded-lg overflow-hidden shadow-md p-4 h-80">
                  <div className="animate-pulse">
                    <div className="bg-gray-300 h-48 w-full rounded mb-4"></div>
                    <div className="h-4 bg-gray-300 rounded w-1/4 mb-2"></div>
                    <div className="h-6 bg-gray-300 rounded w-3/4 mb-2"></div>
                    <div className="h-4 bg-gray-300 rounded w-full mb-2"></div>
                    <div className="h-4 bg-gray-300 rounded w-2/3"></div>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            // Render posts
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              {posts.map((post) => (
                <BlogPostCard key={post.id} post={post} />
              ))}
            </div>
          )}
        </section>
      </main>
      
      <Newsletter />
      <Footer />
    </div>
  );
};

export default Home;
