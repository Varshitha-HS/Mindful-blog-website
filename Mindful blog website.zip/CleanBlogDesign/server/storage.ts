import { users, type User, type InsertUser } from "@shared/schema";
import { posts, type Post, type InsertPost } from "@shared/schema";
import { comments, type Comment, type InsertComment } from "@shared/schema";
import { blogPosts } from "../client/src/lib/data";

// Storage interface for CRUD operations
export interface IStorage {
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  // Post operations
  getPosts(): Promise<Post[]>;
  getPostById(id: number): Promise<Post | undefined>;
  getPostBySlug(slug: string): Promise<Post | undefined>;
  createPost(post: InsertPost): Promise<Post>;
  
  // Comment operations
  getCommentsByPostId(postId: number): Promise<Comment[]>;
  createComment(comment: InsertComment): Promise<Comment>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private posts: Map<number, Post>;
  private comments: Map<number, Comment>;
  private userCurrentId: number;
  private postCurrentId: number;
  private commentCurrentId: number;

  constructor() {
    this.users = new Map();
    this.posts = new Map();
    this.comments = new Map();
    this.userCurrentId = 1;
    this.postCurrentId = 1;
    this.commentCurrentId = 1;
    
    // Seed initial blog posts
    this.seedBlogPosts();
  }

  // User operations
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.userCurrentId++;
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }

  // Post operations
  async getPosts(): Promise<Post[]> {
    return Array.from(this.posts.values());
  }

  async getPostById(id: number): Promise<Post | undefined> {
    return this.posts.get(id);
  }

  async getPostBySlug(slug: string): Promise<Post | undefined> {
    return Array.from(this.posts.values()).find(
      (post) => post.slug === slug,
    );
  }

  async createPost(insertPost: InsertPost): Promise<Post> {
    const id = this.postCurrentId++;
    const now = new Date();
    const post: Post = { 
      ...insertPost, 
      id,
      createdAt: now.toISOString()
    };
    this.posts.set(id, post);
    return post;
  }

  // Comment operations
  async getCommentsByPostId(postId: number): Promise<Comment[]> {
    return Array.from(this.comments.values())
      .filter(comment => comment.postId === postId)
      .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
  }

  async createComment(insertComment: InsertComment): Promise<Comment> {
    const id = this.commentCurrentId++;
    const now = new Date();
    const comment: Comment = { 
      ...insertComment, 
      id,
      createdAt: now.toISOString()
    };
    this.comments.set(id, comment);
    return comment;
  }

  // Seed initial blog posts from data.ts
  private seedBlogPosts() {
    blogPosts.forEach(post => {
      const { id, ...postData } = post;
      
      // Convert to DB format
      const dbPost: Post = {
        id,
        title: postData.title,
        slug: postData.slug,
        date: postData.date,
        excerpt: postData.excerpt,
        content: postData.content,
        imageSrc: postData.imageSrc,
        imageAlt: postData.imageAlt,
        createdAt: new Date().toISOString()
      };
      
      this.posts.set(id, dbPost);
      this.postCurrentId = Math.max(this.postCurrentId, id + 1);
    });
  }
}

export const storage = new MemStorage();
